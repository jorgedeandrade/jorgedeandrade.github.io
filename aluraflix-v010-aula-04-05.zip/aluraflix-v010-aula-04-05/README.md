# AluraFlix v010 Aula 04/05

A Pen created on CodePen.io. Original URL: [https://codepen.io/jorge_andrade/pen/YzLQMdr](https://codepen.io/jorge_andrade/pen/YzLQMdr).

Alterando lista inicial e montando onclick nas outras